package com.example

import com.example.core.compiler.ApkBuilderEngine
import com.example.core.modifier.ProjectCustomizer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class ExampleUnitTest {

  @Test
  fun testInitialStepsNaming() {
    val steps = ApkBuilderEngine.createInitialSteps()
    assertEquals(7, steps.size)
    assertEquals("[ PREPARANDO PROYECTO ]", steps[0].title)
    assertEquals("[ VERIFICANDO ARCHIVOS ]", steps[1].title)
    assertEquals("[ APLICANDO NOMBRE ]", steps[2].title)
    assertEquals("[ APLICANDO ICONO ]", steps[3].title)
    assertEquals("[ CONFIGURANDO ENTORNO GRADLE ]", steps[4].title)
    assertEquals("[ COMPILANDO PROYECTO ORIGINAL ]", steps[5].title)
    assertEquals("[ FIRMANDO Y VERIFICANDO APK ]", steps[6].title)
  }

  @Test
  fun testProjectCustomizerAppName() {
    val tempDir = File.createTempDir("test_project", "")
    try {
      val resValues = File(tempDir, "app/src/main/res/values")
      resValues.mkdirs()
      val stringsFile = File(resValues, "strings.xml")
      stringsFile.writeText(
        """<resources>
    <string name="app_name">Original Name</string>
</resources>"""
      )

      ProjectCustomizer.updateAppName(tempDir, "Nueva App Nativa")

      val updatedText = stringsFile.readText()
      assertTrue(updatedText.contains("<string name=\"app_name\">Nueva App Nativa</string>"))
    } finally {
      tempDir.deleteRecursively()
    }
  }
}

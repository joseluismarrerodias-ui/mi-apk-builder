package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Teal / Emerald & Deep Slate palette
val EmeraldPrimary = Color(0xFF0D9488)
val EmeraldPrimaryLight = Color(0xFF14B8A6)
val EmeraldContainer = Color(0xFFCCFBF1)
val OnEmeraldContainer = Color(0xFF115E59)

val TealSecondary = Color(0xFF0284C7)
val TealContainer = Color(0xFFE0F2FE)
val OnTealContainer = Color(0xFF0369A1)

val SlateBackgroundLight = Color(0xFFF8FAFC)
val SlateSurfaceLight = Color(0xFFFFFFFF)
val SlateSurfaceVariantLight = Color(0xFFF1F5F9)
val SlateTextLight = Color(0xFF0F172A)
val SlateTextSecondaryLight = Color(0xFF64748B)

val SlateBackgroundDark = Color(0xFF0B0F19)
val SlateSurfaceDark = Color(0xFF131B2E)
val SlateSurfaceVariantDark = Color(0xFF1E293B)
val SlateTextDark = Color(0xFFF1F5F9)
val SlateTextSecondaryDark = Color(0xFF94A3B8)

val AccentSuccess = Color(0xFF10B981)
val AccentError = Color(0xFFEF4444)
val AccentWarning = Color(0xFFF59E0B)

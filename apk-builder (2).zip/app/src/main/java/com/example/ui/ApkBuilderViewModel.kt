package com.example.ui

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.core.compiler.ApkBuilderEngine
import com.example.core.model.AndroidProjectInfo
import com.example.core.model.BuildResult
import com.example.core.model.BuildStep
import com.example.core.model.StepStatus
import com.example.core.samples.SampleProjectGenerator
import com.example.core.scanner.ProjectAnalyzer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream

enum class AppStage {
    IDLE,
    ANALYZING,
    PROJECT_READY,
    BUILDING,
    BUILD_SUCCESS,
    ERROR
}

data class ApkBuilderUiState(
    val stage: AppStage = AppStage.IDLE,
    val selectedZipName: String? = null,
    val projectInfo: AndroidProjectInfo? = null,
    val customAppName: String = "",
    val customIconBitmap: Bitmap? = null,
    val buildSteps: List<BuildStep> = ApkBuilderEngine.createInitialSteps(),
    val currentStepTitle: String = "",
    val currentStepIndex: Int = 0,
    val totalSteps: Int = 7,
    val buildResult: BuildResult? = null,
    val errorMessage: String? = null,
    val logs: List<String> = emptyList(),
    val isSampleProject: Boolean = false
)

class ApkBuilderViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(ApkBuilderUiState())
    val uiState: StateFlow<ApkBuilderUiState> = _uiState.asStateFlow()

    private var currentWorkDir: File? = null

    fun loadZipUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    stage = AppStage.ANALYZING,
                    errorMessage = null,
                    buildResult = null
                )
            }

            try {
                val fileName = getFileName(context, uri) ?: "proyecto_android.zip"
                _uiState.update { it.copy(selectedZipName = fileName, isSampleProject = false) }

                withContext(Dispatchers.IO) {
                    val workDir = File(context.cacheDir, "project_work_${System.currentTimeMillis()}")
                    currentWorkDir = workDir

                    context.contentResolver.openInputStream(uri)?.use { inputStream ->
                        ProjectAnalyzer.unzip(inputStream, workDir)
                    } ?: throw IllegalStateException("No se pudo abrir el archivo ZIP seleccionado.")

                    val info = ProjectAnalyzer.analyzeProject(workDir, context)

                    withContext(Dispatchers.Main) {
                        if (info.isValidAndroidProject) {
                            _uiState.update {
                                it.copy(
                                    stage = AppStage.PROJECT_READY,
                                    projectInfo = info,
                                    customAppName = info.appName,
                                    customIconBitmap = info.iconPreviewBitmap,
                                    errorMessage = null
                                )
                            }
                        } else {
                            val errText = if (info.errors.isNotEmpty()) {
                                info.errors.joinToString("\n• ")
                            } else {
                                "El archivo ZIP no contiene un proyecto Android válido con Gradle y Manifest."
                            }
                            _uiState.update {
                                it.copy(
                                    stage = AppStage.ERROR,
                                    projectInfo = info,
                                    errorMessage = "• $errText"
                                )
                            }
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        stage = AppStage.ERROR,
                        errorMessage = "Error al procesar el archivo ZIP: ${e.message ?: "Formato no válido"}"
                    )
                }
            }
        }
    }

    fun loadSampleProject(context: Context) {
        viewModelScope.launch {
            _uiState.update {
                it.copy(
                    stage = AppStage.ANALYZING,
                    selectedZipName = "Proyecto_Android_Ejemplo.zip",
                    errorMessage = null,
                    isSampleProject = true
                )
            }

            try {
                withContext(Dispatchers.IO) {
                    val sampleZip = SampleProjectGenerator.generateSampleProjectZip(context)
                    val workDir = File(context.cacheDir, "sample_work_${System.currentTimeMillis()}")
                    currentWorkDir = workDir

                    FileInputStream(sampleZip).use { fis ->
                        ProjectAnalyzer.unzip(fis, workDir)
                    }

                    val info = ProjectAnalyzer.analyzeProject(workDir, context)

                    withContext(Dispatchers.Main) {
                        _uiState.update {
                            it.copy(
                                stage = AppStage.PROJECT_READY,
                                projectInfo = info,
                                customAppName = info.appName,
                                customIconBitmap = info.iconPreviewBitmap,
                                errorMessage = null
                            )
                        }
                    }
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        stage = AppStage.ERROR,
                        errorMessage = "Error al generar proyecto de prueba: ${e.message}"
                    )
                }
            }
        }
    }

    fun setCustomAppName(name: String) {
        _uiState.update { it.copy(customAppName = name) }
    }

    fun setCustomIcon(bitmap: Bitmap) {
        _uiState.update { it.copy(customIconBitmap = bitmap) }
    }

    fun startBuild(context: Context) {
        val info = _uiState.value.projectInfo ?: return

        viewModelScope.launch {
            val initialSteps = ApkBuilderEngine.createInitialSteps()
            _uiState.update {
                it.copy(
                    stage = AppStage.BUILDING,
                    buildSteps = initialSteps,
                    currentStepIndex = 0,
                    currentStepTitle = initialSteps.firstOrNull()?.title ?: "",
                    errorMessage = null
                )
            }

            val result = ApkBuilderEngine.buildApk(
                context = context,
                projectInfo = info,
                customAppName = _uiState.value.customAppName,
                customIcon = _uiState.value.customIconBitmap,
                onStepUpdate = { stepId, status, message ->
                    _uiState.update { state ->
                        val updated = state.buildSteps.map { s ->
                            if (s.id == stepId) s.copy(status = status, logMessage = message) else s
                        }
                        val activeIdx = updated.indexOfFirst { it.status == StepStatus.RUNNING }
                            .takeIf { it >= 0 } ?: updated.indexOfLast { it.status == StepStatus.COMPLETED }
                        val activeTitle = updated.getOrNull(activeIdx)?.title ?: ""
                        state.copy(
                            buildSteps = updated,
                            currentStepIndex = if (activeIdx >= 0) activeIdx + 1 else 0,
                            currentStepTitle = activeTitle
                        )
                    }
                }
            )

            if (result.isSuccess) {
                _uiState.update {
                    it.copy(
                        stage = AppStage.BUILD_SUCCESS,
                        buildResult = result,
                        logs = result.logs
                    )
                }
            } else {
                _uiState.update {
                    it.copy(
                        stage = AppStage.ERROR,
                        errorMessage = result.errorMessage ?: "Falló la compilación del APK",
                        logs = result.logs
                    )
                }
            }
        }
    }

    fun reset() {
        _uiState.update { ApkBuilderUiState() }
    }

    fun installApk(context: Context) {
        val apkFile = _uiState.value.buildResult?.apkFile ?: return
        if (!apkFile.exists()) {
            Toast.makeText(context, "El archivo APK no fue encontrado.", Toast.LENGTH_SHORT).show()
            return
        }

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )

            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(context, "No se pudo iniciar el instalador: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    fun shareApk(context: Context) {
        val apkFile = _uiState.value.buildResult?.apkFile ?: return
        if (!apkFile.exists()) return

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.fileprovider",
                apkFile
            )

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "application/vnd.android.package-archive"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "APK generado: ${apkFile.name}")
                flags = Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            context.startActivity(Intent.createChooser(intent, "Compartir APK"))
        } catch (e: Exception) {
            Toast.makeText(context, "Error al compartir APK: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    fun saveToDownloads(context: Context) {
        val apkFile = _uiState.value.buildResult?.apkFile ?: return
        if (!apkFile.exists()) return

        viewModelScope.launch(Dispatchers.IO) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val contentValues = ContentValues().apply {
                        put(MediaStore.MediaColumns.DISPLAY_NAME, apkFile.name)
                        put(MediaStore.MediaColumns.MIME_TYPE, "application/vnd.android.package-archive")
                        put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ApkBuilder")
                    }

                    val resolver = context.contentResolver
                    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)

                    if (uri != null) {
                        resolver.openOutputStream(uri)?.use { out ->
                            FileInputStream(apkFile).use { input ->
                                input.copyTo(out)
                            }
                        }
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Guardado en Descargas/ApkBuilder/${apkFile.name}", Toast.LENGTH_LONG).show()
                        }
                    }
                } else {
                    val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
                    val targetFile = File(downloadsDir, apkFile.name)
                    FileInputStream(apkFile).use { input ->
                        FileOutputStream(targetFile).use { out ->
                            input.copyTo(out)
                        }
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Guardado en: ${targetFile.absolutePath}", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "Error al guardar: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun getFileName(context: Context, uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = context.contentResolver.query(uri, null, null, null, null)
            cursor?.use {
                if (it.moveToFirst()) {
                    val index = it.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (index != -1) {
                        result = it.getString(index)
                    }
                }
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != null && cut != -1) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }
}

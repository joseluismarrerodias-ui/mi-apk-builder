package com.example.core.model

import android.graphics.Bitmap
import java.io.File

data class AndroidProjectInfo(
    val projectName: String,
    val appName: String,
    val applicationId: String,
    val versionCode: Int,
    val versionName: String,
    val minSdk: Int,
    val targetSdk: Int,
    val mainActivity: String?,
    val hasKotlinSources: Boolean,
    val hasJavaSources: Boolean,
    val hasCompose: Boolean,
    val hasXmlLayouts: Boolean,
    val sourceFilesCount: Int,
    val resourceFilesCount: Int,
    val detectedFiles: List<String>,
    val permissions: List<String> = emptyList(),
    val activities: List<String> = emptyList(),
    val services: List<String> = emptyList(),
    val dependencies: List<String> = emptyList(),
    val mainModule: String = "app",
    val hasGradleWrapper: Boolean = false,
    val prebuiltApkFile: File? = null,
    val iconPreviewBitmap: Bitmap?,
    val projectRootDir: File,
    val isValidAndroidProject: Boolean,
    val validationMessages: List<String>,
    val errors: List<String>
)

enum class BuildStatus {
    IDLE,
    IN_PROGRESS,
    SUCCESS,
    ERROR
}

data class BuildStep(
    val id: String,
    val title: String,
    val description: String,
    val status: StepStatus = StepStatus.PENDING,
    val logMessage: String? = null
)

enum class StepStatus {
    PENDING,
    RUNNING,
    COMPLETED,
    FAILED
}

data class BuildResult(
    val isSuccess: Boolean,
    val apkFile: File?,
    val apkFileName: String = "",
    val apkSizeFormatted: String = "",
    val apkSha256: String = "",
    val outputDirectory: String = "",
    val buildDurationMs: Long = 0L,
    val errorMessage: String? = null,
    val logs: List<String> = emptyList()
)

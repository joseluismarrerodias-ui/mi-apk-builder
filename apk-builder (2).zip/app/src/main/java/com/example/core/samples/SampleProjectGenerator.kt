package com.example.core.samples

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

object SampleProjectGenerator {

    fun generateSampleProjectZip(context: Context): File {
        val sampleZipFile = File(context.cacheDir, "sample_android_project.zip")
        if (sampleZipFile.exists()) {
            sampleZipFile.delete()
        }

        val zos = ZipOutputStream(FileOutputStream(sampleZipFile))

        // settings.gradle.kts
        writeZipText(
            zos,
            "settings.gradle.kts",
            """
pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}
rootProject.name = "MiAppNativa"
include(":app")
""".trimIndent()
        )

        // build.gradle.kts
        writeZipText(
            zos,
            "build.gradle.kts",
            """
plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
}
""".trimIndent()
        )

        // gradle.properties
        writeZipText(
            zos,
            "gradle.properties",
            """
org.gradle.jvmargs=-Xmx2048m -Dfile.encoding=UTF-8
android.useAndroidX=true
android.nonTransitiveRClass=true
""".trimIndent()
        )

        // app/build.gradle.kts
        writeZipText(
            zos,
            "app/build.gradle.kts",
            """
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
}

android {
    namespace = "com.example.demoapp"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.demoapp"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildFeatures {
        compose = true
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.compose.material3)
}
""".trimIndent()
        )

        // app/src/main/AndroidManifest.xml
        writeZipText(
            zos,
            "app/src/main/AndroidManifest.xml",
            """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.example.demoapp">

    <application
        android:allowBackup="true"
        android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name"
        android:roundIcon="@mipmap/ic_launcher_round"
        android:supportsRtl="true"
        android:theme="@android:style/Theme.Material.Light.NoActionBar">
        <activity
            android:name=".MainActivity"
            android:exported="true"
            android:label="@string/app_name">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>

</manifest>
""".trimIndent()
        )

        // app/src/main/res/values/strings.xml
        writeZipText(
            zos,
            "app/src/main/res/values/strings.xml",
            """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Demo App Nativa</string>
    <string name="welcome_message">¡Hola Mundo desde Kotlin y Compose!</string>
</resources>
""".trimIndent()
        )

        // app/src/main/res/values/colors.xml
        writeZipText(
            zos,
            "app/src/main/res/values/colors.xml",
            """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <color name="primary">#0D9488</color>
    <color name="primary_variant">#0F766E</color>
    <color name="background">#F8FAFC</color>
</resources>
""".trimIndent()
        )

        // app/src/main/java/com/example/demoapp/MainActivity.kt
        writeZipText(
            zos,
            "app/src/main/java/com/example/demoapp/MainActivity.kt",
            """package com.example.demoapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = "¡Aplicación Nativa Compilada con Éxito!")
                }
            }
        }
    }
}
""".trimIndent()
        )

        zos.finish()
        zos.close()

        return sampleZipFile
    }

    private fun writeZipText(zos: ZipOutputStream, path: String, content: String) {
        val entry = ZipEntry(path)
        zos.putNextEntry(entry)
        zos.write(content.toByteArray(Charsets.UTF_8))
        zos.closeEntry()
    }
}

package com.example.core.modifier

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.graphics.RectF
import java.io.File
import java.io.FileOutputStream

object ProjectCustomizer {

    /**
     * Safely updates the app_name string in strings.xml and project files without breaking syntax.
     */
    fun updateAppName(projectRootDir: File, newName: String): Boolean {
        if (newName.isBlank()) return false

        var updated = false

        // 1. Find all strings.xml files (usually app/src/main/res/values/strings.xml)
        val stringsFiles = mutableListOf<File>()
        findFilesByName(projectRootDir, "strings.xml", stringsFiles)

        if (stringsFiles.isEmpty()) {
            // Create strings.xml in app/src/main/res/values/
            val valuesDir = File(projectRootDir, "app/src/main/res/values")
            valuesDir.mkdirs()
            val stringsFile = File(valuesDir, "strings.xml")
            stringsFile.writeText(
                """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">$newName</string>
</resources>
""".trimIndent()
            )
            updated = true
        } else {
            for (file in stringsFiles) {
                try {
                    val content = file.readText()
                    val regex = Regex("""<string\s+name\s*=\s*["']app_name["']>([^<]*)</string>""")
                    if (regex.containsMatchIn(content)) {
                        val newContent = regex.replace(content, """<string name="app_name">$newName</string>""")
                        file.writeText(newContent)
                        updated = true
                    } else if (content.contains("</resources>")) {
                        val newContent = content.replace(
                            "</resources>",
                            "    <string name=\"app_name\">$newName</string>\n</resources>"
                        )
                        file.writeText(newContent)
                        updated = true
                    }
                } catch (e: Exception) {
                    // ignore
                }
            }
        }

        // 2. Update settings.gradle.kts / settings.gradle rootProject.name if exists
        val settingsKts = File(projectRootDir, "settings.gradle.kts")
        if (settingsKts.exists()) {
            try {
                val content = settingsKts.readText()
                val regex = Regex("""rootProject\.name\s*=\s*["'][^"']*["']""")
                if (regex.containsMatchIn(content)) {
                    settingsKts.writeText(regex.replace(content, "rootProject.name = \"$newName\""))
                }
            } catch (e: Exception) {
                // ignore
            }
        }

        val settingsGroovy = File(projectRootDir, "settings.gradle")
        if (settingsGroovy.exists()) {
            try {
                val content = settingsGroovy.readText()
                val regex = Regex("""rootProject\.name\s*=\s*["'][^"']*["']""")
                if (regex.containsMatchIn(content)) {
                    settingsGroovy.writeText(regex.replace(content, "rootProject.name = '$newName'"))
                }
            } catch (e: Exception) {
                // ignore
            }
        }

        return updated
    }

    /**
     * Resizes and updates application icons across all required Android densities.
     */
    fun updateAppIcon(projectRootDir: File, newIcon: Bitmap): Boolean {
        val resDirs = mutableListOf<File>()
        collectResDirs(projectRootDir, resDirs)

        if (resDirs.isEmpty()) {
            // Default to app/src/main/res
            val defaultRes = File(projectRootDir, "app/src/main/res")
            defaultRes.mkdirs()
            resDirs.add(defaultRes)
        }

        val iconSizes = mapOf(
            "mipmap-mdpi" to 48,
            "mipmap-hdpi" to 72,
            "mipmap-xhdpi" to 96,
            "mipmap-xxhdpi" to 144,
            "mipmap-xxxhdpi" to 192
        )

        for (res in resDirs) {
            for ((folderName, size) in iconSizes) {
                val folder = File(res, folderName)
                folder.mkdirs()

                // Generate square icon
                val squareBmp = Bitmap.createScaledBitmap(newIcon, size, size, true)
                saveBitmapToPng(squareBmp, File(folder, "ic_launcher.png"))
                // Also overwrite webp if existing
                val webpFile = File(folder, "ic_launcher.webp")
                if (webpFile.exists()) {
                    saveBitmapToPng(squareBmp, webpFile)
                }

                // Generate round icon
                val roundBmp = getCircularBitmap(squareBmp)
                saveBitmapToPng(roundBmp, File(folder, "ic_launcher_round.png"))
                val roundWebp = File(folder, "ic_launcher_round.webp")
                if (roundWebp.exists()) {
                    saveBitmapToPng(roundBmp, roundWebp)
                }
            }

            // Save foreground asset for adaptive icons
            val drawableFolder = File(res, "drawable")
            drawableFolder.mkdirs()
            val fgBmp = Bitmap.createScaledBitmap(newIcon, 432, 432, true)
            saveBitmapToPng(fgBmp, File(drawableFolder, "ic_launcher_foreground.png"))
            saveBitmapToPng(fgBmp, File(drawableFolder, "ic_app_icon_art.png"))
        }

        return true
    }

    private fun getCircularBitmap(bitmap: Bitmap): Bitmap {
        val output = Bitmap.createBitmap(bitmap.width, bitmap.height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(output)
        val color = -0xbdbdbe
        val paint = Paint().apply {
            isAntiAlias = true
            isFilterBitmap = true
            this.color = color
        }
        val rect = Rect(0, 0, bitmap.width, bitmap.height)
        val rectF = RectF(rect)
        canvas.drawARGB(0, 0, 0, 0)
        canvas.drawOval(rectF, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(bitmap, rect, rect, paint)
        return output
    }

    private fun saveBitmapToPng(bitmap: Bitmap, targetFile: File) {
        FileOutputStream(targetFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.flush()
        }
    }

    private fun findFilesByName(dir: File, name: String, result: MutableList<File>) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                if (f.name != ".gradle" && f.name != "build") {
                    findFilesByName(f, name, result)
                }
            } else if (f.name.equals(name, ignoreCase = true)) {
                result.add(f)
            }
        }
    }

    private fun collectResDirs(dir: File, list: MutableList<File>) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                if (f.name == "res") {
                    list.add(f)
                } else if (f.name != ".gradle" && f.name != "build") {
                    collectResDirs(f, list)
                }
            }
        }
    }
}

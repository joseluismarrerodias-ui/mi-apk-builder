package com.example.core.compiler

import android.util.Base64
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.math.BigInteger
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.Signature
import java.security.cert.X509Certificate
import java.util.Date
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

/**
 * Signs an APK file with a standard Android Debug Keystore using APK v1 signing (JAR signing).
 */
object ApkSigner {

    private var cachedKeyPair: KeyPair? = null

    private fun getOrCreateKeyPair(): KeyPair {
        cachedKeyPair?.let { return it }
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp = kpg.generateKeyPair()
        cachedKeyPair = kp
        return kp
    }

    fun signApk(unsignedApk: File, signedApk: File) {
        val keyPair = getOrCreateKeyPair()
        val privateKey = keyPair.private
        val publicKey = keyPair.public

        val zipFile = ZipFile(unsignedApk)
        val entries = zipFile.entries()

        // 1. Calculate digest for each file and build MANIFEST.MF
        val manifestMf = ByteArrayOutputStream()
        manifestMf.write("Manifest-Version: 1.0\r\n".toByteArray())
        manifestMf.write("Created-By: 1.0 (Android APK Builder)\r\n\r\n".toByteArray())

        val entryDigestMap = mutableMapOf<String, ByteArray>()
        val entrySectionMap = mutableMapOf<String, ByteArray>()

        val md = MessageDigest.getInstance("SHA-256")

        val sortedEntries = mutableListOf<ZipEntry>()
        while (entries.hasMoreElements()) {
            val entry = entries.nextElement()
            if (!entry.name.startsWith("META-INF/")) {
                sortedEntries.add(entry)
            }
        }
        sortedEntries.sortBy { it.name }

        for (entry in sortedEntries) {
            val isStream = zipFile.getInputStream(entry)
            val buf = ByteArray(8192)
            var len: Int
            md.reset()
            while (isStream.read(buf).also { len = it } > 0) {
                md.update(buf, 0, len)
            }
            val digest = md.digest()
            val digestBase64 = Base64.encodeToString(digest, Base64.NO_WRAP)

            val section = "Name: ${entry.name}\r\nSHA-256-Digest: $digestBase64\r\n\r\n".toByteArray()
            manifestMf.write(section)
            entryDigestMap[entry.name] = digest
            entrySectionMap[entry.name] = section
        }

        val manifestMfBytes = manifestMf.toByteArray()

        // 2. Build CERT.SF
        val certSf = ByteArrayOutputStream()
        certSf.write("Signature-Version: 1.0\r\n".toByteArray())
        certSf.write("Created-By: 1.0 (Android APK Builder)\r\n".toByteArray())

        md.reset()
        val manifestDigest = md.digest(manifestMfBytes)
        val manifestDigestBase64 = Base64.encodeToString(manifestDigest, Base64.NO_WRAP)
        certSf.write("SHA-256-Digest-Manifest: $manifestDigestBase64\r\n\r\n".toByteArray())

        for (entry in sortedEntries) {
            val section = entrySectionMap[entry.name] ?: continue
            md.reset()
            val sectionDigest = md.digest(section)
            val sectionDigestBase64 = Base64.encodeToString(sectionDigest, Base64.NO_WRAP)
            certSf.write("Name: ${entry.name}\r\nSHA-256-Digest: $sectionDigestBase64\r\n\r\n".toByteArray())
        }

        val certSfBytes = certSf.toByteArray()

        // 3. Sign CERT.SF with RSA Private Key and generate CERT.RSA (PKCS#7 block)
        val sig = Signature.getInstance("SHA256withRSA")
        sig.initSign(privateKey)
        sig.update(certSfBytes)
        val signatureBytes = sig.sign()

        val certRsaBytes = buildPkcs7Block(publicKey.encoded, signatureBytes, certSfBytes)

        // 4. Output signed APK
        if (signedApk.exists()) signedApk.delete()
        val zos = ZipOutputStream(FileOutputStream(signedApk))

        // First write META-INF entries
        writeZipEntry(zos, "META-INF/MANIFEST.MF", manifestMfBytes)
        writeZipEntry(zos, "META-INF/CERT.SF", certSfBytes)
        writeZipEntry(zos, "META-INF/CERT.RSA", certRsaBytes)

        // Copy all other entries from unsigned APK
        for (entry in sortedEntries) {
            val newEntry = ZipEntry(entry.name)
            zos.putNextEntry(newEntry)
            zipFile.getInputStream(entry).use { inStream ->
                inStream.copyTo(zos)
            }
            zos.closeEntry()
        }

        zos.finish()
        zos.close()
        zipFile.close()
    }

    private fun writeZipEntry(zos: ZipOutputStream, name: String, data: ByteArray) {
        val entry = ZipEntry(name)
        zos.putNextEntry(entry)
        zos.write(data)
        zos.closeEntry()
    }

    /**
     * Builds a self-contained PKCS#7 / CMS ContentInfo structure for the RSA signature and cert.
     */
    private fun buildPkcs7Block(pubKeyEncoded: ByteArray, signature: ByteArray, signedData: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()

        // ASN.1 Sequence helper
        fun encodeLength(len: Int): ByteArray {
            return if (len < 128) {
                byteArrayOf(len.toByte())
            } else if (len < 256) {
                byteArrayOf(0x81.toByte(), len.toByte())
            } else if (len < 65536) {
                byteArrayOf(0x82.toByte(), (len shr 8).toByte(), (len and 0xFF).toByte())
            } else {
                byteArrayOf(0x83.toByte(), (len shr 16).toByte(), ((len shr 8) and 0xFF).toByte(), (len and 0xFF).toByte())
            }
        }

        fun wrapSequence(content: ByteArray): ByteArray {
            val len = encodeLength(content.size)
            val res = ByteArray(1 + len.size + content.size)
            res[0] = 0x30.toByte() // SEQUENCE tag
            System.arraycopy(len, 0, res, 1, len.size)
            System.arraycopy(content, 0, res, 1 + len.size, content.size)
            return res
        }

        fun wrapOctetString(content: ByteArray): ByteArray {
            val len = encodeLength(content.size)
            val res = ByteArray(1 + len.size + content.size)
            res[0] = 0x04.toByte() // OCTET STRING tag
            System.arraycopy(len, 0, res, 1, len.size)
            System.arraycopy(content, 0, res, 1 + len.size, content.size)
            return res
        }

        fun wrapBitString(content: ByteArray): ByteArray {
            val len = encodeLength(content.size + 1)
            val res = ByteArray(2 + len.size + content.size)
            res[0] = 0x03.toByte() // BIT STRING tag
            System.arraycopy(len, 0, res, 1, len.size)
            res[1 + len.size] = 0x00.toByte() // 0 unused bits
            System.arraycopy(content, 0, res, 2 + len.size, content.size)
            return res
        }

        // SHA-256 OID: 2.16.840.1.101.3.4.2.1 -> 06 09 60 86 48 01 65 03 04 02 01
        val sha256Oid = byteArrayOf(0x06, 0x09, 0x60, 0x86.toByte(), 0x48, 0x01, 0x65, 0x03, 0x04, 0x02, 0x01)
        // RSA OID: 1.2.840.113549.1.1.1 -> 06 09 2A 86 48 86 F7 0D 01 01 01
        val rsaOid = byteArrayOf(0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x01, 0x01)
        // PKCS7 SignedData OID: 1.2.840.113549.1.7.2 -> 06 09 2A 86 48 86 F7 0D 01 07 02
        val signedDataOid = byteArrayOf(0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x07, 0x02)
        // PKCS7 Data OID: 1.2.840.113549.1.7.1 -> 06 09 2A 86 48 86 F7 0D 01 07 01
        val dataOid = byteArrayOf(0x06, 0x09, 0x2A, 0x86.toByte(), 0x48, 0x86.toByte(), 0xF7.toByte(), 0x0D, 0x01, 0x07, 0x01)

        // SignerInfo:
        // Version 1 (INTEGER 1) -> 02 01 01
        val versionInt = byteArrayOf(0x02, 0x01, 0x01)
        // IssuerAndSerialNumber (dummy debug issuer and serial)
        val issuerAndSerial = wrapSequence(
            byteArrayOf(
                0x30, 0x13, 0x31, 0x11, 0x30, 0x0F, 0x06, 0x03, 0x55, 0x04, 0x03, 0x13, 0x08, 0x41, 0x6E, 0x64, 0x72, 0x6F, 0x69, 0x64, // CN=Android
                0x02, 0x01, 0x01 // Serial 1
            )
        )

        val digestAlgorithm = wrapSequence(sha256Oid)
        val digestEncryptionAlgorithm = wrapSequence(rsaOid)
        val encryptedDigest = wrapOctetString(signature)

        val signerInfo = wrapSequence(
            versionInt + issuerAndSerial + digestAlgorithm + digestEncryptionAlgorithm + encryptedDigest
        )
        val signerInfos = byteArrayOf(0x31) + encodeLength(signerInfo.size) + signerInfo // SET OF SignerInfo

        // DigestAlgorithms: SET OF DigestAlgorithmIdentifier
        val digestAlgorithms = byteArrayOf(0x31) + encodeLength(digestAlgorithm.size) + digestAlgorithm

        // EncapsulatedContentInfo: OID data (1.2.840.113549.1.7.1)
        val encapContentInfo = wrapSequence(dataOid)

        // SignedData content: version, digestAlgorithms, encapContentInfo, certificates [0], signerInfos
        val certsTagged = byteArrayOf(0xA0.toByte()) + encodeLength(pubKeyEncoded.size) + pubKeyEncoded

        val signedDataSeq = wrapSequence(
            versionInt + digestAlgorithms + encapContentInfo + certsTagged + signerInfos
        )

        // Outer ContentInfo: OID signedData, [0] SignedData
        val contentInfoTagged = byteArrayOf(0xA0.toByte()) + encodeLength(signedDataSeq.size) + signedDataSeq
        val pkcs7 = wrapSequence(signedDataOid + contentInfoTagged)

        return pkcs7
    }
}

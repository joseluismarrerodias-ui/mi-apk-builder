package com.example.core.scanner

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import com.example.core.model.AndroidProjectInfo
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream

object ProjectAnalyzer {

    /**
     * Unzips a file stream to a destination directory safely.
     */
    fun unzip(zipStream: InputStream, targetDir: File): Boolean {
        if (targetDir.exists()) {
            targetDir.deleteRecursively()
        }
        targetDir.mkdirs()

        val buffer = ByteArray(8192)
        val canonicalDestDirPath = targetDir.canonicalPath

        ZipInputStream(BufferedInputStream(zipStream)).use { zis ->
            var entry: ZipEntry? = zis.nextEntry
            while (entry != null) {
                val newFile = File(targetDir, entry.name)
                val canonicalDestPath = newFile.canonicalPath
                if (!canonicalDestPath.startsWith(canonicalDestDirPath + File.separator) &&
                    canonicalDestPath != canonicalDestDirPath
                ) {
                    throw SecurityException("Zip slip detected: ${entry.name}")
                }

                if (entry.isDirectory) {
                    newFile.mkdirs()
                } else {
                    newFile.parentFile?.mkdirs()
                    FileOutputStream(newFile).use { fos ->
                        var len: Int
                        while (zis.read(buffer).also { len = it } > 0) {
                            fos.write(buffer, 0, len)
                        }
                    }
                }
                zis.closeEntry()
                entry = zis.nextEntry
            }
        }
        return true
    }

    /**
     * Finds the real root of the Android project in the unzipped folder.
     */
    fun findProjectRoot(baseDir: File): File {
        // Check if baseDir itself contains settings.gradle / settings.gradle.kts or build.gradle / build.gradle.kts
        if (isAndroidProjectRoot(baseDir)) {
            return baseDir
        }

        // Check subdirectories (e.g. if the ZIP had a single root folder)
        val subDirs = baseDir.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: emptyArray()
        for (sub in subDirs) {
            if (isAndroidProjectRoot(sub)) {
                return sub
            }
        }

        // Search up to 3 levels deep
        val found = searchForRoot(baseDir, 0, 3)
        return found ?: baseDir
    }

    private fun searchForRoot(dir: File, currentDepth: Int, maxDepth: Int): File? {
        if (currentDepth > maxDepth) return null
        if (isAndroidProjectRoot(dir)) return dir

        val children = dir.listFiles { f -> f.isDirectory && !f.name.startsWith(".") } ?: return null
        for (child in children) {
            val res = searchForRoot(child, currentDepth + 1, maxDepth)
            if (res != null) return res
        }
        return null
    }

    private fun isAndroidProjectRoot(dir: File): Boolean {
        val hasSettings = File(dir, "settings.gradle.kts").exists() || File(dir, "settings.gradle").exists()
        val hasBuild = File(dir, "build.gradle.kts").exists() || File(dir, "build.gradle").exists()
        val hasApp = File(dir, "app").exists() || File(dir, "src").exists()
        return (hasSettings || hasBuild) && hasApp
    }

    /**
     * Analyzes the Android project and extracts all metadata and configurations.
     */
    fun analyzeProject(projectDir: File, context: Context? = null): AndroidProjectInfo {
        val realRoot = findProjectRoot(projectDir)
        val validationMessages = mutableListOf<String>()
        val errors = mutableListOf<String>()
        val detectedFiles = mutableListOf<String>()

        // 1. Settings Gradle Check
        val settingsFileKts = File(realRoot, "settings.gradle.kts")
        val settingsFileGroovy = File(realRoot, "settings.gradle")
        val hasSettings = settingsFileKts.exists() || settingsFileGroovy.exists()

        if (hasSettings) {
            val name = if (settingsFileKts.exists()) "settings.gradle.kts" else "settings.gradle"
            validationMessages.add("Archivo de configuración '$name' detectado")
            detectedFiles.add(name)
        } else {
            errors.add("No se encontró settings.gradle ni settings.gradle.kts")
        }

        // 2. Root Build Gradle Check
        val buildFileKts = File(realRoot, "build.gradle.kts")
        val buildFileGroovy = File(realRoot, "build.gradle")
        val hasRootBuild = buildFileKts.exists() || buildFileGroovy.exists()

        if (hasRootBuild) {
            val name = if (buildFileKts.exists()) "build.gradle.kts" else "build.gradle"
            validationMessages.add("Script de compilación raíz '$name' detectado")
            detectedFiles.add(name)
        } else {
            errors.add("No se encontró build.gradle ni build.gradle.kts en la raíz")
        }

        // 3. App Module Check
        val appDir = File(realRoot, "app")
        val appBuildKts = File(appDir, "build.gradle.kts")
        val appBuildGroovy = File(appDir, "build.gradle")
        val hasAppBuild = appBuildKts.exists() || appBuildGroovy.exists()

        if (hasAppBuild) {
            val name = if (appBuildKts.exists()) "app/build.gradle.kts" else "app/build.gradle"
            validationMessages.add("Módulo de aplicación '$name' detectado")
            detectedFiles.add(name)
        } else {
            // Check if root itself is the app module (single module project)
            val rootSrc = File(realRoot, "src/main/AndroidManifest.xml")
            if (!rootSrc.exists()) {
                errors.add("No se encontró el módulo 'app' ni la carpeta 'src/main'")
            }
        }

        // 4. AndroidManifest.xml Check
        var manifestFile = File(appDir, "src/main/AndroidManifest.xml")
        if (!manifestFile.exists()) {
            manifestFile = File(realRoot, "src/main/AndroidManifest.xml")
        }
        if (!manifestFile.exists()) {
            // Search anywhere in project
            manifestFile = findFileByName(realRoot, "AndroidManifest.xml") ?: manifestFile
        }

        val hasManifest = manifestFile.exists()
        var manifestPackage = ""
        var manifestLabel = ""
        var mainActivityName: String? = null
        val permissionsList = mutableListOf<String>()
        val activitiesList = mutableListOf<String>()
        val servicesList = mutableListOf<String>()

        if (hasManifest) {
            validationMessages.add("AndroidManifest.xml detectado")
            detectedFiles.add("AndroidManifest.xml")
            val manifestContent = try { manifestFile.readText() } catch (e: Exception) { "" }
            manifestPackage = extractPackageFromManifest(manifestContent)
            manifestLabel = extractLabelFromManifest(manifestContent)
            mainActivityName = extractMainActivityFromManifest(manifestContent)
            activitiesList.addAll(extractAllActivitiesFromManifest(manifestContent))
            servicesList.addAll(extractAllServicesFromManifest(manifestContent))
            permissionsList.addAll(extractPermissionsFromManifest(manifestContent))
            if (permissionsList.isNotEmpty()) {
                validationMessages.add("${permissionsList.size} permisos declarados en Manifest")
            }
            if (activitiesList.isNotEmpty()) {
                validationMessages.add("${activitiesList.size} actividades declaradas")
            }
        } else {
            errors.add("No se encontró AndroidManifest.xml en el proyecto")
        }

        // 5. Gradle Wrapper Check
        val gradlewUnix = File(realRoot, "gradlew")
        val gradlewBat = File(realRoot, "gradlew.bat")
        val hasGradleWrapper = gradlewUnix.exists() || gradlewBat.exists()
        if (hasGradleWrapper) {
            validationMessages.add("Gradle Wrapper detectado (gradlew)")
            detectedFiles.add("gradlew")
        }

        // 6. Dependencies Check
        val dependenciesList = mutableListOf<String>()
        val appBuildContent = try {
            if (appBuildKts.exists()) appBuildKts.readText()
            else if (appBuildGroovy.exists()) appBuildGroovy.readText()
            else ""
        } catch (e: Exception) { "" }
        if (appBuildContent.isNotBlank()) {
            dependenciesList.addAll(extractDependenciesFromGradle(appBuildContent))
            if (dependenciesList.isNotEmpty()) {
                validationMessages.add("${dependenciesList.size} dependencias declaradas")
            }
        }

        // 7. App Name from strings.xml
        var appName = ""
        val stringsFile = findFileInProject(realRoot, "strings.xml")
        if (stringsFile != null && stringsFile.exists()) {
            detectedFiles.add("res/values/strings.xml")
            val stringsContent = try { stringsFile.readText() } catch (e: Exception) { "" }
            appName = extractAppNameFromStrings(stringsContent)
        }

        if (appName.isBlank()) {
            if (manifestLabel.isNotBlank() && !manifestLabel.startsWith("@string/")) {
                appName = manifestLabel
            } else {
                // Fallback to rootProject.name in settings.gradle.kts or dir name
                val settingsContent = try {
                    if (settingsFileKts.exists()) settingsFileKts.readText()
                    else if (settingsFileGroovy.exists()) settingsFileGroovy.readText()
                    else ""
                } catch (e: Exception) { "" }
                appName = extractRootProjectName(settingsContent)
                if (appName.isBlank()) {
                    appName = realRoot.name.replace("_", " ").replace("-", " ")
                }
            }
        }

        // 8. ApplicationId / Namespace / SDK from Gradle
        var applicationId = ""
        var versionCode = 1
        var versionName = "1.0"
        var minSdk = 24
        var targetSdk = 34

        if (appBuildContent.isNotBlank()) {
            val parsedAppId = extractApplicationId(appBuildContent)
            if (parsedAppId.isNotBlank()) applicationId = parsedAppId

            val parsedNamespace = extractNamespace(appBuildContent)
            if (applicationId.isBlank() && parsedNamespace.isNotBlank()) {
                applicationId = parsedNamespace
            }

            val parsedMinSdk = extractIntProperty(appBuildContent, "minSdk")
            if (parsedMinSdk > 0) minSdk = parsedMinSdk

            val parsedTargetSdk = extractIntProperty(appBuildContent, "targetSdk")
            if (parsedTargetSdk > 0) targetSdk = parsedTargetSdk

            val parsedVersionCode = extractIntProperty(appBuildContent, "versionCode")
            if (parsedVersionCode > 0) versionCode = parsedVersionCode

            val parsedVersionName = extractStringProperty(appBuildContent, "versionName")
            if (parsedVersionName.isNotBlank()) versionName = parsedVersionName
        }

        if (applicationId.isBlank()) {
            applicationId = if (manifestPackage.isNotBlank()) manifestPackage else "com.example.${cleanPackageName(appName)}"
        }

        // 9. Check for prebuilt APK in project
        val prebuiltApk = findApkInProject(realRoot)

        // 10. Source files and resource scan
        var kotlinCount = 0
        var javaCount = 0
        var xmlCount = 0
        var resCount = 0
        var hasCompose = false

        countFiles(realRoot) { file ->
            when {
                file.name.endsWith(".kt") -> {
                    kotlinCount++
                    val text = try { file.readText() } catch (e: Exception) { "" }
                    if (text.contains("@Composable") || text.contains("androidx.compose")) {
                        hasCompose = true
                    }
                }
                file.name.endsWith(".java") -> javaCount++
                file.name.endsWith(".xml") -> {
                    xmlCount++
                    if (file.parentFile?.parentFile?.name == "res" || file.parentFile?.name == "res") {
                        resCount++
                    }
                }
            }
        }

        if (kotlinCount > 0) {
            validationMessages.add("$kotlinCount archivos Kotlin (.kt) encontrados")
        }
        if (javaCount > 0) {
            validationMessages.add("$javaCount archivos Java (.java) encontrados")
        }
        if (hasCompose) {
            validationMessages.add("Interfaz moderna con Jetpack Compose detectada")
        }

        // 11. Launcher Icon detection
        val iconBitmap = findAndLoadIcon(realRoot)

        val totalSources = kotlinCount + javaCount
        if (totalSources == 0 && prebuiltApk == null) {
            errors.add("No se encontraron archivos de código fuente (.kt ni .java)")
        }

        val isValid = errors.isEmpty() && hasManifest && (hasSettings || hasRootBuild)

        return AndroidProjectInfo(
            projectName = realRoot.name,
            appName = if (appName.isBlank()) "Mi App Android" else appName,
            applicationId = applicationId,
            versionCode = versionCode,
            versionName = versionName,
            minSdk = minSdk,
            targetSdk = targetSdk,
            mainActivity = mainActivityName,
            hasKotlinSources = kotlinCount > 0,
            hasJavaSources = javaCount > 0,
            hasCompose = hasCompose,
            hasXmlLayouts = xmlCount > 0,
            sourceFilesCount = totalSources,
            resourceFilesCount = resCount,
            detectedFiles = detectedFiles,
            permissions = permissionsList,
            activities = activitiesList,
            services = servicesList,
            dependencies = dependenciesList,
            mainModule = if (hasAppBuild) "app" else ":",
            hasGradleWrapper = hasGradleWrapper,
            prebuiltApkFile = prebuiltApk,
            iconPreviewBitmap = iconBitmap,
            projectRootDir = realRoot,
            isValidAndroidProject = isValid,
            validationMessages = validationMessages,
            errors = errors
        )
    }

    private fun countFiles(dir: File, onFile: (File) -> Unit) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                if (f.name != ".gradle" && f.name != "build" && f.name != ".git" && f.name != ".idea") {
                    countFiles(f, onFile)
                }
            } else {
                onFile(f)
            }
        }
    }

    private fun findFileByName(dir: File, name: String): File? {
        val files = dir.listFiles() ?: return null
        for (f in files) {
            if (f.isDirectory) {
                if (f.name != ".gradle" && f.name != "build") {
                    val found = findFileByName(f, name)
                    if (found != null) return found
                }
            } else if (f.name.equals(name, ignoreCase = true)) {
                return f
            }
        }
        return null
    }

    private fun findFileInProject(dir: File, fileName: String): File? {
        return findFileByName(dir, fileName)
    }

    private fun findAndLoadIcon(rootDir: File): Bitmap? {
        val resDirs = mutableListOf<File>()
        collectResDirs(rootDir, resDirs)

        // Preference order for icon files
        val possibleNames = listOf(
            "ic_launcher.png",
            "ic_launcher.webp",
            "ic_launcher_round.png",
            "ic_app_icon_art.jpg",
            "ic_app_icon_art.png",
            "ic_launcher.jpg"
        )

        val densities = listOf("mipmap-xxxhdpi", "mipmap-xxhdpi", "mipmap-xhdpi", "mipmap-hdpi", "mipmap-mdpi", "drawable")

        for (res in resDirs) {
            for (density in densities) {
                val folder = File(res, density)
                if (folder.exists() && folder.isDirectory) {
                    for (iconName in possibleNames) {
                        val iconFile = File(folder, iconName)
                        if (iconFile.exists() && iconFile.length() > 0) {
                            try {
                                val bmp = BitmapFactory.decodeFile(iconFile.absolutePath)
                                if (bmp != null) return bmp
                            } catch (e: Exception) {
                                // ignore
                            }
                        }
                    }
                }
            }
        }
        return null
    }

    private fun collectResDirs(dir: File, list: MutableList<File>) {
        val files = dir.listFiles() ?: return
        for (f in files) {
            if (f.isDirectory) {
                if (f.name == "res") {
                    list.add(f)
                } else if (f.name != ".gradle" && f.name != "build") {
                    collectResDirs(f, list)
                }
            }
        }
    }

    private fun extractPackageFromManifest(content: String): String {
        val pkgRegex = Regex("""package\s*=\s*["']([^"']+)["']""")
        return pkgRegex.find(content)?.groupValues?.get(1) ?: ""
    }

    private fun extractLabelFromManifest(content: String): String {
        val labelRegex = Regex("""android:label\s*=\s*["']([^"']+)["']""")
        return labelRegex.find(content)?.groupValues?.get(1) ?: ""
    }

    private fun extractMainActivityFromManifest(content: String): String? {
        val activityRegex = Regex("""<activity[^>]*android:name\s*=\s*["']([^"']+)["'][^>]*>""", RegexOption.DOT_MATCHES_ALL)
        val match = activityRegex.find(content)
        return match?.groupValues?.get(1)
    }

    private fun extractPermissionsFromManifest(content: String): List<String> {
        val permRegex = Regex("""<uses-permission[^>]*android:name\s*=\s*["']([^"']+)["']""")
        return permRegex.findAll(content).map { it.groupValues[1] }.distinct().toList()
    }

    private fun extractAppNameFromStrings(content: String): String {
        val regex = Regex("""<string\s+name\s*=\s*["']app_name["']>([^<]+)</string>""")
        return regex.find(content)?.groupValues?.get(1)?.trim() ?: ""
    }

    private fun extractRootProjectName(content: String): String {
        val regex = Regex("""rootProject\.name\s*=\s*["']([^"']+)["']""")
        return regex.find(content)?.groupValues?.get(1)?.trim() ?: ""
    }

    private fun extractApplicationId(content: String): String {
        val regex = Regex("""applicationId\s*=\s*["']([^"']+)["']""")
        val match = regex.find(content)
        if (match != null) return match.groupValues[1]

        val groovyRegex = Regex("""applicationId\s+["']([^"']+)["']""")
        return groovyRegex.find(content)?.groupValues?.get(1) ?: ""
    }

    private fun extractNamespace(content: String): String {
        val regex = Regex("""namespace\s*=\s*["']([^"']+)["']""")
        val match = regex.find(content)
        if (match != null) return match.groupValues[1]

        val groovyRegex = Regex("""namespace\s+["']([^"']+)["']""")
        return groovyRegex.find(content)?.groupValues?.get(1) ?: ""
    }

    private fun extractIntProperty(content: String, propName: String): Int {
        val regex = Regex("""$propName\s*=\s*(\d+)""")
        val match = regex.find(content)
        if (match != null) return match.groupValues[1].toIntOrNull() ?: 0

        val groovyRegex = Regex("""$propName\s+(\d+)""")
        val gMatch = groovyRegex.find(content)
        if (gMatch != null) return gMatch.groupValues[1].toIntOrNull() ?: 0

        // Handle compileSdk { version = release(36) }
        val releaseRegex = Regex("""release\((\d+)\)""")
        return releaseRegex.find(content)?.groupValues?.get(1)?.toIntOrNull() ?: 0
    }

    private fun extractStringProperty(content: String, propName: String): String {
        val regex = Regex("""$propName\s*=\s*["']([^"']+)["']""")
        val match = regex.find(content)
        if (match != null) return match.groupValues[1]

        val groovyRegex = Regex("""$propName\s+["']([^"']+)["']""")
        return groovyRegex.find(content)?.groupValues?.get(1) ?: ""
    }

    private fun extractAllActivitiesFromManifest(content: String): List<String> {
        val activityRegex = Regex("""<activity[^>]*android:name\s*=\s*["']([^"']+)["']""", RegexOption.DOT_MATCHES_ALL)
        return activityRegex.findAll(content).map { it.groupValues[1] }.distinct().toList()
    }

    private fun extractAllServicesFromManifest(content: String): List<String> {
        val serviceRegex = Regex("""<service[^>]*android:name\s*=\s*["']([^"']+)["']""", RegexOption.DOT_MATCHES_ALL)
        return serviceRegex.findAll(content).map { it.groupValues[1] }.distinct().toList()
    }

    private fun extractDependenciesFromGradle(content: String): List<String> {
        val results = mutableListOf<String>()
        val implRegex = Regex("""(?:implementation|api|compileOnly|runtimeOnly)\s*\(([^)]+)\)""")
        for (m in implRegex.findAll(content)) {
            results.add(m.groupValues[1].trim('"', '\'', ' '))
        }
        val groovyImplRegex = Regex("""(?:implementation|api)\s+["']([^"']+)["']""")
        for (m in groovyImplRegex.findAll(content)) {
            results.add(m.groupValues[1].trim())
        }
        return results.distinct()
    }

    private fun findApkInProject(dir: File): File? {
        val candidateDirs = listOf(
            File(dir, "app/build/outputs/apk/debug"),
            File(dir, "app/build/outputs/apk/release"),
            File(dir, "build/outputs/apk/debug"),
            File(dir, "build/outputs/apk")
        )
        for (cand in candidateDirs) {
            if (cand.exists() && cand.isDirectory) {
                val apk = cand.listFiles { f -> f.isFile && f.name.endsWith(".apk") && f.length() > 0 }?.firstOrNull()
                if (apk != null) return apk
            }
        }
        return null
    }

    private fun cleanPackageName(name: String): String {
        return name.lowercase().replace(Regex("[^a-z0-9]"), "")
    }
}

package com.example.core.compiler

import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader
import java.util.concurrent.TimeUnit

class GradleBuildException(
    val failedTask: String?,
    val errorDetails: String,
    val explanation: String,
    cause: Throwable? = null
) : Exception(explanation, cause)

object GradleProjectCompiler {

    /**
     * Executes real Gradle build tasks (:app:assembleDebug) on the target unzipped Android project.
     * Streams real stdout/stderr lines and returns the generated APK file.
     */
    fun compileProject(
        projectDir: File,
        mainModule: String = "app",
        onLog: (String) -> Unit
    ): File {
        onLog("Iniciando entorno de compilación Gradle...")

        val gradlewUnix = File(projectDir, "gradlew")
        val gradlewBat = File(projectDir, "gradlew.bat")

        // 1. Locate Gradle executable
        val executable: String
        if (gradlewUnix.exists()) {
            try {
                gradlewUnix.setExecutable(true, false)
            } catch (e: Exception) {
                // ignore
            }
            executable = gradlewUnix.absolutePath
            onLog("Ejecutable Gradle Wrapper detectado: $executable")
        } else if (gradlewBat.exists() && isWindows()) {
            executable = gradlewBat.absolutePath
            onLog("Ejecutable Gradle Wrapper (Windows) detectado: $executable")
        } else {
            // Check if system gradle is available
            val systemGradle = findSystemCommand("gradle")
            if (systemGradle != null) {
                executable = systemGradle
                onLog("Gradle del sistema detectado: $executable")
            } else {
                throw GradleBuildException(
                    failedTask = ":preBuild",
                    errorDetails = "No se encontró el ejecutable 'gradlew' ni 'gradle' en el proyecto.",
                    explanation = "El proyecto no contiene el archivo ejecutable 'gradlew' (Gradle Wrapper) en la raíz ni existe un binario de Gradle en el sistema. Asegúrate de incluir el Gradle Wrapper completo en el ZIP."
                )
            }
        }

        // 2. Setup Android SDK and Java Environment
        val env = mutableMapOf<String, String>()
        val androidHome = findAndroidSdkPath()
        if (androidHome != null) {
            env["ANDROID_HOME"] = androidHome
            env["ANDROID_SDK_ROOT"] = androidHome
            onLog("Android SDK configurado: $androidHome")
        } else {
            onLog("Aviso: ANDROID_HOME no encontrado en variables estándar. Gradle intentará resolverlo localmente.")
        }

        val javaHome = System.getenv("JAVA_HOME") ?: System.getProperty("java.home")
        if (javaHome != null) {
            env["JAVA_HOME"] = javaHome
            onLog("Java JDK configurado: $javaHome")
        }

        // 3. Prepare task name
        val cleanModule = mainModule.trim(':', ' ')
        val taskName = if (cleanModule.isNotBlank() && cleanModule != ".") ":$cleanModule:assembleDebug" else "assembleDebug"
        onLog("Tarea Gradle a ejecutar: $taskName")

        val command = mutableListOf(
            executable,
            taskName,
            "--stacktrace",
            "--info",
            "-Dorg.gradle.daemon=false",
            "-Dorg.gradle.parallel=false",
            "-Dfile.encoding=UTF-8"
        )

        val pb = ProcessBuilder(command)
        pb.directory(projectDir)
        pb.environment().putAll(env)
        pb.redirectErrorStream(true)

        val outputBuffer = StringBuilder()
        var failedTaskName: String? = null
        val errorLines = mutableListOf<String>()

        var process: Process? = null
        try {
            onLog("Ejecutando comando: ${command.joinToString(" ")}")
            process = pb.start()

            val reader = BufferedReader(InputStreamReader(process.inputStream))
            var line: String?
            while (reader.readLine().also { line = it } != null) {
                val currentLine = line ?: continue
                outputBuffer.append(currentLine).append("\n")
                onLog(currentLine)

                if (currentLine.contains("> Task :") && currentLine.contains("FAILED")) {
                    failedTaskName = currentLine.substringAfter("> Task ").substringBefore(" FAILED").trim()
                }

                if (currentLine.contains("ERROR:") || currentLine.contains("e: ") || currentLine.contains("FAILURE:") || currentLine.contains("FAILED")) {
                    errorLines.add(currentLine)
                }
            }

            val exited = process.waitFor(10, TimeUnit.MINUTES)
            if (!exited) {
                process.destroyForcibly()
                throw GradleBuildException(
                    failedTask = taskName,
                    errorDetails = "Tiempo de espera agotado (10 minutos) durante la compilación.",
                    explanation = "La compilación de Gradle tardó más de 10 minutos y fue cancelada para evitar bloqueo del sistema."
                )
            }

            val exitCode = process.exitValue()
            onLog("Gradle finalizó con código de salida: $exitCode")

            if (exitCode != 0) {
                val errorSummary = if (errorLines.isNotEmpty()) {
                    errorLines.takeLast(10).joinToString("\n")
                } else {
                    outputBuffer.takeLast(1500).toString()
                }

                val explanation = buildUserFriendlyExplanation(failedTaskName, errorSummary)

                throw GradleBuildException(
                    failedTask = failedTaskName ?: taskName,
                    errorDetails = errorSummary,
                    explanation = explanation
                )
            }

            // 4. Locate the generated APK
            val apkFile = findGeneratedApk(projectDir, cleanModule)
                ?: throw GradleBuildException(
                    failedTask = taskName,
                    errorDetails = "Gradle finalizó con éxito pero no se encontró el APK en app/build/outputs/apk/.",
                    explanation = "La compilación concluyó pero no se localizó el archivo APK resultante en las rutas estándar de salida de Gradle."
                )

            onLog("APK generado por Gradle localizado: ${apkFile.absolutePath} (${apkFile.length()} bytes)")
            return apkFile

        } catch (e: GradleBuildException) {
            throw e
        } catch (e: Exception) {
            val msg = e.message ?: e.toString()
            onLog("Error al ejecutar el proceso de compilación Gradle: $msg")
            throw GradleBuildException(
                failedTask = failedTaskName ?: taskName,
                errorDetails = msg,
                explanation = "No se pudo ejecutar el compilador Gradle en este entorno: $msg. Verifica que los binarios y dependencias del proyecto sean compatibles.",
                cause = e
            )
        } finally {
            process?.destroy()
        }
    }

    private fun findGeneratedApk(projectDir: File, module: String): File? {
        val searchDirs = listOf(
            File(projectDir, "$module/build/outputs/apk/debug"),
            File(projectDir, "app/build/outputs/apk/debug"),
            File(projectDir, "build/outputs/apk/debug"),
            File(projectDir, "$module/build/outputs/apk/release"),
            File(projectDir, "app/build/outputs/apk/release"),
            File(projectDir, "build/outputs/apk")
        )

        for (dir in searchDirs) {
            if (dir.exists() && dir.isDirectory) {
                val apks = dir.listFiles { f -> f.isFile && f.name.endsWith(".apk") && f.length() > 0 }
                if (!apks.isNullOrEmpty()) {
                    // Prefer debug APKs
                    val debugApk = apks.find { it.name.contains("debug", ignoreCase = true) }
                    return debugApk ?: apks.first()
                }
            }
        }

        // Recursive search in build/outputs/apk if not found
        val buildOutputsDir = File(projectDir, "app/build/outputs/apk")
        if (buildOutputsDir.exists()) {
            val found = findApkRecursively(buildOutputsDir)
            if (found != null) return found
        }

        return findApkRecursively(projectDir)
    }

    private fun findApkRecursively(dir: File): File? {
        val files = dir.listFiles() ?: return null
        for (f in files) {
            if (f.isDirectory) {
                if (f.name == "build" || f.name == "outputs" || f.name == "apk" || f.name == "debug") {
                    val res = findApkRecursively(f)
                    if (res != null) return res
                }
            } else if (f.name.endsWith(".apk") && f.length() > 0) {
                return f
            }
        }
        return null
    }

    private fun buildUserFriendlyExplanation(failedTask: String?, errorSummary: String): String {
        return when {
            errorSummary.contains("Unresolved reference") || errorSummary.contains("cannot find symbol") -> {
                "Error de compilación de código fuente: Hay clases, funciones o dependencias faltantes en el código Kotlin/Java del proyecto."
            }
            errorSummary.contains("Could not resolve") || errorSummary.contains("Failed to resolve") -> {
                "Error de dependencias Gradle: No se pudieron resolver una o más librerías requeridas por el proyecto. Verifica la conexión a internet o los repositorios configurados."
            }
            errorSummary.contains("AAPT: error") || errorSummary.contains("Resource compilation failed") -> {
                "Error en recursos Android: Hay un problema de sintaxis o conflicto en los archivos XML de res/ (layouts, drawables, strings o manifest)."
            }
            errorSummary.contains("compileSdkVersion") || errorSummary.contains("compileSdk") -> {
                "Error de SDK: La versión de 'compileSdk' o Android Gradle Plugin requerida por el proyecto no coincide con el entorno de compilación."
            }
            failedTask != null -> {
                "Falló la tarea Gradle '$failedTask'. Revisa los registros de compilación para ver el detalle exacto del error."
            }
            else -> {
                "Falló la compilación Gradle del proyecto original. Consulta el registro de compilación para más detalles."
            }
        }
    }

    private fun findAndroidSdkPath(): String? {
        val envPaths = listOf(
            System.getenv("ANDROID_HOME"),
            System.getenv("ANDROID_SDK_ROOT"),
            System.getProperty("android.home")
        )
        for (p in envPaths) {
            if (!p.isNullOrBlank() && File(p).exists()) return p
        }

        val commonPaths = listOf(
            "/opt/android-sdk",
            "/opt/android-sdk-linux",
            "/usr/local/android-sdk",
            "/data/data/com.termux/files/home/android-sdk"
        )
        for (p in commonPaths) {
            val f = File(p)
            if (f.exists() && f.isDirectory) return f.absolutePath
        }
        return null
    }

    private fun findSystemCommand(cmd: String): String? {
        val pathEnv = System.getenv("PATH") ?: return null
        val paths = pathEnv.split(File.pathSeparator)
        for (p in paths) {
            val file = File(p, cmd)
            if (file.exists() && file.canExecute()) {
                return file.absolutePath
            }
        }
        return null
    }

    private fun isWindows(): Boolean {
        return System.getProperty("os.name")?.contains("win", ignoreCase = true) == true
    }
}
